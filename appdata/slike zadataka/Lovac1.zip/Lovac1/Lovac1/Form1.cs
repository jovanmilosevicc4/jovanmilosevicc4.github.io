﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lovac1
{
    public partial class Form1 : Form
    {
        private Point startPosPlayer;   // početna pozicija button2
        private Point startPosEnemy1;   // početna pozicija button5
        private Point startPosEnemy2;   // početna pozicija button6

        private int normalSpeed = 5;     // normalna brzina igrača
        private int playerSpeed;         // trenutna brzina igrača
        
        public Form1()
        {
            InitializeComponent();

            // Početne pozicije
            startPosPlayer = button2.Location;
            startPosEnemy1 = button5.Location;
            startPosEnemy2 = button6.Location;

            // Postavi početnu brzinu
            playerSpeed = normalSpeed;

            // Podesi timer3 za privremeno ubrzanje
            timer3.Interval = 10000; // 10 sekundi
            timer3.Tick += Timer3_Tick;
            timer3.Stop();
            
        }
        
        // Kretanje igrača
        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            int poeni = Convert.ToInt32(label2.Text);
            int brzina = playerSpeed;
            int newLeft = button2.Left;
            int newTop = button2.Top;

            if (e.KeyChar == 'w') newTop -= playerSpeed;
            if (e.KeyChar == 's') newTop += playerSpeed;
            if (e.KeyChar == 'a') newLeft -= playerSpeed;
            if (e.KeyChar == 'd') newLeft += playerSpeed;

            // Granice forme
            if (newLeft < 0) newLeft = 1;
            if (newTop < 0) newTop = 1;
            if (newLeft > 755) newLeft = 754;
            if (newTop > 365) newTop = 364;

            // Barijera teleport button3 i button4
            if (poeni < 10)
            {
                Rectangle futurePos = new Rectangle(newLeft, newTop, button2.Width, button2.Height);
                if (futurePos.IntersectsWith(button3.Bounds) || futurePos.IntersectsWith(button4.Bounds))
                {
                    newLeft = button2.Left;
                    newTop = button2.Top;
                }
            }

            button2.Left = newLeft;
            button2.Top = newTop;
        }

        // Start igre
        private void button1_Click(object sender, EventArgs e)
        {
            button2.Focus();
            timer1.Start();
            timer2.Start();
        }

        // Timer za kretanje neprijatelja i teleport / sudar
        private void timer1_Tick(object sender, EventArgs e)
        {
            Random x = new Random();
            // Kretanje button5
            int smer = x.Next(4);
            if (smer == 0) button5.Left += 4;
            if (smer == 1) button5.Top += 4;
            if (smer == 2) button5.Left -= 4;
            if (smer == 3) button5.Top -= 4;
            smer = x.Next(4);
            if (smer == 0) button5.Left += 4;
            if (smer == 1) button5.Top += 4;
            if (smer == 2) button5.Left -= 4;
            if (smer == 3) button5.Top -= 4;

            // Praćenje igrača
            if ((button2.Top > button5.Top) && (button2.Left > button5.Left)) { button5.Top += 4; button5.Left += 4; }
            if ((button2.Top < button5.Top) && (button2.Left < button5.Left)) { button5.Top -= 4; button5.Left -= 4; }
            if ((button2.Top > button5.Top) && (button2.Left < button5.Left)) { button5.Top += 4; button5.Left -= 4; }
            if ((button2.Top < button5.Top) && (button2.Left > button5.Left)) { button5.Top -= 4; button5.Left += 4; }

            if ((button2.Top > button6.Top) && (button2.Left > button6.Left)) { button6.Top += 4; button6.Left += 4; }
            if ((button2.Top < button6.Top) && (button2.Left < button6.Left)) { button6.Top -= 4; button6.Left -= 4; }
            if ((button2.Top > button6.Top) && (button2.Left < button6.Left)) { button6.Top += 4; button6.Left -= 4; }
            if ((button2.Top < button6.Top) && (button2.Left > button6.Left)) { button6.Top -= 4; button6.Left += 4; }

            int poeni = Convert.ToInt32(label2.Text);

            // Teleport button3 → button4
            if (button2.Bounds.IntersectsWith(button3.Bounds))
            {
                if (poeni >= 10)
                {
                    poeni -= 10;
                    label2.Text = poeni.ToString();
                    button2.Left = button4.Left - button2.Width - 10;
                    button2.Top = button4.Top;
                }
            }

            // Teleport button4 → button3
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                if (poeni >= 10)
                {
                    poeni -= 10;
                    label2.Text = poeni.ToString();
                    button2.Left = button3.Left + button3.Width + 10;
                    button2.Top = button3.Top;
                }
            }

            // Sudar sa neprijateljima → game over
            if (button2.Bounds.IntersectsWith(button5.Bounds) || button2.Bounds.IntersectsWith(button6.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                MessageBox.Show("GAME OVER");

                button2.Location = startPosPlayer;
                button5.Location = startPosEnemy1;
                button6.Location = startPosEnemy2;
                label2.Text = "0";
            }

            // Pobednički uslov
            if (poeni >= 30)
            {
                timer1.Stop();
                timer2.Stop();
                MessageBox.Show("POBEDILI STE!");

                button2.Location = startPosPlayer;
                button5.Location = startPosEnemy1;
                button6.Location = startPosEnemy2;
                label2.Text = "0";
            }
        }

        // Timer za poene
        private void timer2_Tick(object sender, EventArgs e)
        {
            int poeni = Convert.ToInt32(label2.Text);
            poeni++;
            label2.Text = poeni.ToString();
        }

        // Timer3 → privremeno ubrzanje
        private void Timer3_Tick(object sender, EventArgs e)
        {
           
        }

        // Klik na button7 → privremeno ubrzanje
        private void button7_Click(object sender, EventArgs e)
        {
            int poeni = Convert.ToInt32(label2.Text);

            if (poeni >= 5)
            {
                poeni -= 5;
                label2.Text = poeni.ToString();

                playerSpeed += 5;

                timer3.Stop(); // restart ako je već pokrenut
                timer3.Start();
            }
            else
            {
                MessageBox.Show("Nema dovoljno poena za ubrzanje!");
            }
            // Vrati fokus na button2 da KeyPress radi
            button2.Focus();
        }

        private void timer3_Tick_1(object sender, EventArgs e)
        {
            playerSpeed = normalSpeed;
            timer3.Stop();
        }
    }
}
