﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace liste_igrica
{
    public partial class Form1 : Form
    {
        List<Button> lista = new List<Button>(); // lista "poena"
        int brojtastera = 10; // koliko dugmića se pojavljuje
        int poeni = 0;        // broj osvojenih poena
        Random rand = new Random(); // zajednički Random objekat

        public Form1()
        {
            InitializeComponent();
            label1.Text = "Poeni: 0";
            timer1.Interval = 100; // brzina neprijatelja (100ms)
            timer1.Tick += timer1_Tick;
        }

        // Klik na "Start"
        private void button1_Click(object sender, EventArgs e)
        {
            poeni = 0;
            label1.Text = "Poeni: 0";
            brojtastera = 10;
            button3.PerformClick(); // generiši poene
            button2.Focus();
            timer1.Start(); // pokreni neprijatelja
        }

        // Generisanje novih tastera (poena)
        private void button3_Click(object sender, EventArgs e)
        {
            lista.Clear();
            panel2.Controls.Clear();
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button4);

            for (int i = 0; i < brojtastera; i++)
            {
                Button taster = new Button();
                int x = rand.Next(0, panel2.Width - 25);
                int y = rand.Next(0, panel2.Height - 25);

                taster.BackColor = Color.FromArgb(rand.Next(255), rand.Next(255), rand.Next(255));
                taster.Left = x;
                taster.Top = y;
                taster.Width = 20;
                taster.Height = 20;

                panel2.Controls.Add(taster);
                lista.Add(taster);
            }
            button2.Focus();
        }

        // Kretanje igrača
        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            int pomak = 10;

            if (e.KeyChar == 'a' && button2.Left > 0)
                button2.Left -= pomak;
            if (e.KeyChar == 'd' && button2.Right < panel2.Width)
                button2.Left += pomak;
            if (e.KeyChar == 'w' && button2.Top > 0)
                button2.Top -= pomak;
            if (e.KeyChar == 's' && button2.Bottom < panel2.Height)
                button2.Top += pomak;

            // Sudar sa poenima
            for (int i = lista.Count - 1; i >= 0; i--)
            {
                Button taster = lista[i];
                if (button2.Bounds.IntersectsWith(taster.Bounds))
                {
                    panel2.Controls.Remove(taster);
                    lista.RemoveAt(i);
                    taster.Dispose();
                    poeni++;
                    label1.Text = "Poeni: " + poeni;
                }
            }

            // Ako su svi poeni sakupljeni
            if (lista.Count == 0)
            {
                brojtastera += 5;
                button3.PerformClick();
            }
        }

        // Kretanje neprijatelja (button4)
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Praćenje igrača
            if (button4.Left < button2.Left)
                button4.Left += 4;
            else if (button4.Left > button2.Left)
                button4.Left -= 4;

            if (button4.Top < button2.Top)
                button4.Top += 4;
            else if (button4.Top > button2.Top)
                button4.Top -= 4;

            // Granice panela
            if (button4.Left < 0) button4.Left = 0;
            if (button4.Top < 0) button4.Top = 0;
            if (button4.Right > panel2.Width) button4.Left = panel2.Width - button4.Width;
            if (button4.Bottom > panel2.Height) button4.Top = panel2.Height - button4.Height;

            // Sudar sa igračem → kraj igre
            if (button4.Bounds.IntersectsWith(button2.Bounds))
            {
                timer1.Stop();
                MessageBox.Show($"Izgubio si! Ukupan broj poena: {poeni}", "Kraj igre");
            }
        }
    }
}



