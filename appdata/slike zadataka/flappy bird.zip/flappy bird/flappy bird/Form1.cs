﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace flappy_bird
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            button2.Location = new Point(12, 125);
            if (e.KeyChar == 'a') button2.Left -= 5;
            if (e.KeyChar == 's') button2.Top += 5;
            if (e.KeyChar == 'd') button2.Left += 5;
            if (e.KeyChar == 'w') button2.Top -= 5;
            if (button2.Left > 755) button2.Left = button2.Left - 5;
            if (button2.Top > 313) button2.Top = 313;
            if (button2.Left < 0) button2.Left = button2.Left + 5;
            if (button2.Top < 18) button2.Top = 18;
            if (e.KeyChar == ' ') button2.Top = button2.Top - 30;
            if(button3.Left<-10)
            {
                Random x = new Random();
                int visina = x.Next(0, 270) + 20;
                button3.Height = visina;
                button4.Top = visina + 70;
                button3.Left = 340;
                button4.Left = 340;
            }
            if(button2.Bounds.IntersectsWith(button3.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                MessageBox.Show("Dotakli ste zid!");
               
            }
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                MessageBox.Show("Dotakli ste zid!");
                

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
            button2.Focus();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button3.Left -= 10;
            button4.Left -= 10;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            button2.Top += 5;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
            button2.Focus();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
