﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Shooting_Star
{
    public partial class Form1 : Form
    {
        int pravac;

        // Lista metkova
        List<Button> metkovi = new List<Button>();
        int maxMetkova = 3;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Imas 4 zivota, ako i jedan od pravugaonika padne ispod gubis zivot!");
            timer1.Start();
            button2.Focus();
        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') pravac = 0;
            if (e.KeyChar == 'd') pravac = 1;

            // Pucanje više metkova
            if (e.KeyChar == ' ')
            {
                if (metkovi.Count < maxMetkova)
                {
                    Button m = new Button();
                    m.Width = 10;
                    m.Height = 20;
                    m.BackColor = Color.Red;

                    m.Left = button2.Left + button2.Width / 2 - 5;
                    m.Top = button2.Top - 20;

                    panel2.Controls.Add(m);
                    metkovi.Add(m);

                    timer2.Start();
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // Kretanje igraca
            if (pravac == 0) button2.Left -= 10;
            if (pravac == 1) button2.Left += 10;

            // "wrapping"
            if (button2.Left >= 796) button2.Left = -28;
            if (button2.Left <= -30) button2.Left = 793;

            // meteori padaju
            button4.Top += 2;
            button5.Top += 3;
            button6.Top += 4;

            // provera pada
            ProveriPadanje(button4);
            ProveriPadanje(button5);
            ProveriPadanje(button6);
        }

        void ProveriPadanje(Button meteor)
        {
            if (meteor.Top > 420)
            {
                meteor.Top = 0;

                if (button10.Left == 706) button10.Left = 1000;
                else if (button10.Left == 1000 && button9.Left == 680) button9.Left = 1000;
                else if (button9.Left == 1000 && button8.Left == 654) button8.Left = 1000;
                else if (button8.Left == 1000 && button7.Left == 628)
                {
                    timer1.Stop();
                    MessageBox.Show("GAME OVER!");
                    ResetIgre();
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int poeni = Convert.ToInt32(label2.Text);

            foreach (Button m in metkovi.ToList())
            {
                m.Top -= 20;

                // *** OVDJE DODATO ODUZIMANJE POENA AKO METAK PROMASI ***
                if (m.Top < 0)
                {
                    poeni--; // ODUZIMANJE POENA KADA METAK PROMASI
                    panel2.Controls.Remove(m);
                    metkovi.Remove(m);
                    continue;
                }

                if (m.Bounds.IntersectsWith(button4.Bounds))
                    pogodak(button4, m, ref poeni);

                else if (m.Bounds.IntersectsWith(button5.Bounds))
                    pogodak(button5, m, ref poeni);

                else if (m.Bounds.IntersectsWith(button6.Bounds))
                    pogodak(button6, m, ref poeni);
            }

            label2.Text = poeni.ToString();
        }


        void pogodak(Button meteor, Button metak, ref int poeni)
        {
            Random x = new Random();
            meteor.Top = 0;
            meteor.Left = x.Next(0, 714);

            panel2.Controls.Remove(metak);
            metkovi.Remove(metak);

            poeni++;
        }

        // RESET IGRE
        void ResetIgre()
        {
            // Reset poena
            label2.Text = "0";

            // Reset meteora
            Random r = new Random();

            button4.Top = 0;
            button4.Left = r.Next(0, 714);

            button5.Top = 0;
            button5.Left = r.Next(0, 714);

            button6.Top = 0;
            button6.Left = r.Next(0, 714);

            // Reset života
            button10.Left = 706;
            button9.Left = 680;
            button8.Left = 654;
            button7.Left = 628;

            // Ukloni metkove
            foreach (Button m in metkovi)
                panel2.Controls.Remove(m);

            metkovi.Clear();

            pravac = -1;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
