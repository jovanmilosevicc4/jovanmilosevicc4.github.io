﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ping_pong
{
    public partial class Form1 : Form
    {
        int brz1 = 3;
        int brz2 = 3;
        Point b4Start, b5Start, b6Start, b7Start, b8Start, b9Start, b10Start,
      b11Start, b12Start, b13Start, b14Start, b15Start, b16Start, b17Start,
      b18Start, b19Start, b20Start, b21Start, b22Start, b23Start, b24Start,
      b25Start, b26Start, b27Start, b28Start, b29Start, b30Start, b31Start,
      b32Start, b33Start;
        public Form1()
        {
            InitializeComponent();
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Reset poena
            label2.Text = "0";

            // Reset brzine
            brz1 = 3;
            brz2 = 3;

            // Reset pozicije lopte
            button3.Left = 300;  // postavi početnu X poziciju
            button3.Top = 150;   // postavi početnu Y poziciju
            button4.Location = b4Start;
            button5.Location = b5Start;
            button6.Location = b6Start;
            button7.Location = b7Start;
            button8.Location = b8Start;
            button9.Location = b9Start;
            button10.Location = b10Start;
            button11.Location = b11Start;
            button12.Location = b12Start;
            button13.Location = b13Start;
            button14.Location = b14Start;
            button15.Location = b15Start;
            button16.Location = b16Start;
            button17.Location = b17Start;
            button18.Location = b18Start;
            button19.Location = b19Start;
            button20.Location = b20Start;
            button21.Location = b21Start;
            button22.Location = b22Start;
            button23.Location = b23Start;
            button24.Location = b24Start;
            button25.Location = b25Start;
            button26.Location = b26Start;
            button27.Location = b27Start;
            button28.Location = b28Start;
            button29.Location = b29Start;
            button30.Location = b30Start;
            button31.Location = b31Start;
            button32.Location = b32Start;
            button33.Location = b33Start;

            timer1.Start();
            button2.Focus(); 
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button3.Left += brz1;
            button3.Top += brz2;
            int poeni = Convert.ToInt16(label2.Text);
            if (button3.Top > 317)
            {
                timer1.Stop();
                MessageBox.Show("Game Over!!!");
                brz2 = (-1) * brz2;
            }
            if (button3.Left > 641)
                brz1 = (-1) * brz1;
            if (button3.Top < 0)
                brz2 = (-1) * brz2;
            if (button3.Left < 0)
                brz1 = (-1) * brz1;
            //ovo je platforma
            if (button3.Bounds.IntersectsWith(button2.Bounds))
                brz2 = (-1) * brz2;
            //blokovi
            if (button3.Bounds.IntersectsWith(button4.Bounds))
            {
                button4.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button5.Bounds))
            {
                button5.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button6.Bounds))
            {
                button6.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button7.Bounds))
            {
                button7.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button8.Bounds))
            {
                button8.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button9.Bounds))
            {
                button9.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button10.Bounds))
            {
                button10.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button11.Bounds))
            {
                button11.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button12.Bounds))
            {
                button12.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button13.Bounds))
            {
                button13.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button14.Bounds))
            {
                button14.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button15.Bounds))
            {
                button15.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button16.Bounds))
            {
                button16.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button17.Bounds))
            {
                button17.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button18.Bounds))
            {
                button18.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button19.Bounds))
            {
                button19.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button20.Bounds))
            {
                button20.Left = 1500;
                brz2 = (-1) * brz2; 
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button21.Bounds))
            {
                button21.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button22.Bounds))
            {
                button22.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button23.Bounds))
            {
                button23.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button24.Bounds))
            {
                button24.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button25.Bounds))
            {
                button25.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button26.Bounds))
            {
                button26.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button27.Bounds))
            {
                button27.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button28.Bounds))
            {
                button28.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button29.Bounds))
            {
                button29.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button30.Bounds))
            {
                button30.Left = 1500;
                brz2 = (-1) * brz2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button31.Bounds))
            {
                button31.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button32.Bounds))
            {
                button32.Left = 1500;
                brz2 = ((-1) * brz2) + 2;
                poeni++;
                label2.Text = Convert.ToString(poeni);

            }
            if (button3.Bounds.IntersectsWith(button33.Bounds))
            {
                button33.Left = 1500;
                brz2 = ((-1) * brz2)+2;
                poeni++;
                label2.Text = Convert.ToString(poeni);
                
            }

        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') // levo
            {
                if (button2.Left > 0) // ne može da ide dalje od leve ivice
                    button2.Left -= 10;
            }
            if (e.KeyChar == 'd') // desno
            {
                if (button2.Right < this.ClientSize.Width) // ne može da pređe desnu ivicu
                    button2.Left += 10;
            }
           
        }

        private void button34_Click(object sender, EventArgs e)
        {
            button2.Focus();
        }

        private void button35_Click(object sender, EventArgs e)
        {
            int poeni = Convert.ToInt16(label2.Text);
            if (poeni > 2)
            {
                button2.Width += 15;
                poeni -= 3;
                label2.Text = Convert.ToString(poeni);
                button2.Focus();
            }
            else
                button2.Focus();
        }

        private void button34_Click_1(object sender, EventArgs e)
        {
            int poeni = Convert.ToInt16(label2.Text);
            if (brz2 < 3 || brz1 < 3)
                button2.Focus();
            if (poeni > 1)
            {
                brz2 -= 2;
                brz1 -= 2;
                poeni -= 2;
                label2.Text = Convert.ToString(poeni);
                button2.Focus();
            }
            else
                button2.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            b4Start = new Point(button4.Left, button4.Top);
            b5Start = new Point(button5.Left, button5.Top);
            b6Start = new Point(button6.Left, button6.Top);
            b7Start = new Point(button7.Left, button7.Top);
            b8Start = new Point(button8.Left, button8.Top);
            b9Start = new Point(button9.Left, button9.Top);
            b10Start = new Point(button10.Left, button10.Top);
            b11Start = new Point(button11.Left, button11.Top);
            b12Start = new Point(button12.Left, button12.Top);
            b13Start = new Point(button13.Left, button13.Top);
            b14Start = new Point(button14.Left, button14.Top);
            b15Start = new Point(button15.Left, button15.Top);
            b16Start = new Point(button16.Left, button16.Top);
            b17Start = new Point(button17.Left, button17.Top);
            b18Start = new Point(button18.Left, button18.Top);
            b19Start = new Point(button19.Left, button19.Top);
            b20Start = new Point(button20.Left, button20.Top);
            b21Start = new Point(button21.Left, button21.Top);
            b22Start = new Point(button22.Left, button22.Top);
            b23Start = new Point(button23.Left, button23.Top);
            b24Start = new Point(button24.Left, button24.Top);
            b25Start = new Point(button25.Left, button25.Top);
            b26Start = new Point(button26.Left, button26.Top);
            b27Start = new Point(button27.Left, button27.Top);
            b28Start = new Point(button28.Left, button28.Top);
            b29Start = new Point(button29.Left, button29.Top);
            b30Start = new Point(button30.Left, button30.Top);
            b31Start = new Point(button31.Left, button31.Top);
            b32Start = new Point(button32.Left, button32.Top);
            b33Start = new Point(button33.Left, button33.Top);
        }
    }
}
