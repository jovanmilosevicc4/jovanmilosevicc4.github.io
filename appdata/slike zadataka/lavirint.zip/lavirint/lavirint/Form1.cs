﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lavirint
{

    public partial class Form1 : Form
    {
        
        int x = 0, y = 0;
        int oldx = 0, oldy = 0;
        List<Button> cvet = new List<Button>();
        int[,] niz =
        {{0,0,0,0,0,0,0,0,0,0},
            {0,1,1,1,0,0,1,1,1,0 },
            {0,0,0,0,0,0,0,0,0,0 },
            {0,1,0,1,1,1,1,0,1,0 },
            {0,1,0,1,0,0,0,0,1,0 },
            {0,1,0,0,0,0,1,0,1,0 },
            {0,1,0,1,1,1,1,0,1,0 },
            {0,0,0,0,0,0,0,0,0,0 },
            {0,1,1,1,0,0,1,1,1,0 },
            {0,0,0,0,0,0,0,0,0,0 }
        };

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
           
            
             
            

            oldx = x;oldy = y;
            if (e.KeyChar == 'a') { button2.Left -= 40;x--; }
            if (e.KeyChar == 's') { button2.Top += 40; y++; }
            if (e.KeyChar == 'd') { button2.Left += 40; x++; }
            if (e.KeyChar == 'w') { button2.Top -= 40; y--; }
            // NE DOZVOLI IZLAZ IZ PANEL2
            if (button2.Left < 0)
            {
                button2.Left = 0;
                x = oldx;
            }

            if (button2.Top < 0)
            {
                button2.Top = 0;
                y = oldy;
            }

            if (button2.Right > panel2.Width)
            {
                button2.Left = panel2.Width - button2.Width;
                x = oldx;
            }

            if (button2.Bottom > panel2.Height)
            {
                button2.Top = panel2.Height - button2.Height;
                y = oldy;
            }

            if (niz[y, x] == 1)
            {
                x = oldx;
                y = oldy;
                button2.Left = x * 40;
                button2.Top = y * 40;

            }
            for(int i=0;i<cvet.Count;i++)
            {
                if(button2.Bounds.IntersectsWith(cvet[i].Bounds))
                {
                    cvet[i].Dispose();
                    cvet.Remove(cvet[i]);
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"d:\pacman.wav");
                    player.Play();


                }

            }
            if (cvet.Count == 0) button3.PerformClick();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Random broj = new Random();
            int z1 = broj.Next(0, 255);
            int z2 = broj.Next(0, 255);
            int z3= broj.Next(0, 255);
            for(int i=0;i<10;i++)
                for(int j = 0; j < 10; j++)
                {
                    if(niz[i,j]==1)
                    {
                        Button taster = new Button();
                        panel2.Controls.Add(taster);
                        taster.Location = new Point(j * 40, i * 40);
                        taster.BackColor = Color.Blue;
                        taster.Size = new Size(40, 40);

                    }
                    if(niz[i,j]==0)
                    {
                        Button taster = new Button();
                        panel2.Controls.Add(taster);
                        taster.Location = new Point(j * 40 + 10, i * 40 + 10);
                        taster.BackColor = System.Drawing.Color.FromArgb(z1, z2, z3);
                        taster.Size = new Size(20, 20);
                        cvet.Insert(0, taster);
                    }

                }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

           
               

            // Provera da li je uhvatio igraca
            if (button4.Bounds.IntersectsWith(button2.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER!");
                Application.Exit();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            button3.PerformClick();
            button2.Focus();
           
            
        }

        

        public Form1()
        {
            InitializeComponent();
        }
    }
}
